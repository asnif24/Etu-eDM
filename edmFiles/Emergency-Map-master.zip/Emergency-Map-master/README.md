# Emergency-Map
This project is our result in HackNTU, Fall, 2015. 

The team members include i-liszt, HCYtaxi, asnif24, and charliee0201.

The idea of this project can be traced to the huge explosion event in Tianjin City, 2015.
We think that a wiki map can provide amount of functions. In this project, we began from disaster. For citizens, they can know the event in the dangerous region, even avoiding danger; for rescue team, they can quickly know the situation of regions and speed up the schedule of rescue. Besides search and rescue, in the future, this project can be generally extented to other fields, like food or trip. People can rapidly get information from our map if needed, and share events to others. Life of the city will be more smart if concept of wiki map can be implement.
