var map, 
	infoWindow = new google.maps.InfoWindow,
	drawingTool = new google.maps.drawing.DrawingManager();

var categoryChosen = "danger",
	icons = ['casualty', 'danger', 'support', 'water'], 
	idCount = 0;

var markers = [];

var tmpPosition, 
	tmpShape;

var casualtyRange = [0, 10, 30, 50,]
	waterRange = [0, 50, 100, 150];

$(function(){
	initMap();
	$('div.btn-move').addClass("btn-clicked");

	// Filter the markers by category
	$("a.category").click(function(e) {
		clearMarkers();
		e.stopPropagation();
		e.preventDefault();

		var category = $(this).parent().parent().attr('id');

		$.each(markers, function(i, marker) {
			if (this.category != category) {
				this.visible = false;

				if (this.regionShape != null)
					this.regionShape.visible = false;
			} else {
				this.visible = true;

				if (this.regionShape != null)
					this.regionShape.visible = true;
			}

			if (category == "all") {
				this.visible = true;

				if (this.regionShape != null)
					this.regionShape.visible = true;
			}
		});

		showMarkers();
	});

	// Filter the markers by option
	$("a.option").click(function(e) {
		clearMarkers();
		e.stopPropagation();
		e.preventDefault();
		
		var data = $(this).attr('data-option');

		var tmp = data.split('-'), 
			category = tmp[0], 
			option = tmp[1];

		$.each(markers, function(i, marker) {
			if (this.category != category) {
				this.visible = false;

				if (this.regionShape != null)
					this.regionShape.visible = false;

			} else {
				if ((this.category == "danger") || (this.category == "support")) {
					if (this.data != option) {
						this.visible = false;

						if (this.regionShape != null)
							this.regionShape.visible = false;
					}
					else {
						this.visible = true;

						if (this.regionShape != null)
							this.regionShape.visible = true;
					}

				} else {
					var markerNum = parseInt(this.data), 
						optionNum = parseInt(option);

					if (tmp[2]) {
						if (markerNum > optionNum) {
							this.visible = false;

							if (this.regionShape != null)
								this.regionShape.visible = false;
						}
						else {
							this.visible = true;

							if (this.regionShape != null)
								this.regionShape.visible = true;
						}

					} else {
						if (markerNum < optionNum) {
							this.visible = false;

							if (this.regionShape != null)
								this.regionShape.visible = false;
						}
						else {
							this.visible = true;

							if (this.regionShape != null)
								this.regionShape.visible = true;
						}
					}
				}
			}
		});

		showMarkers();
	});

	// The function to initialize our map
	function initMap() {
		center();
		var initLocation = new google.maps.LatLng(25.040365, 121.512559);

		$.getJSON( "data/demo.json", function(json) {
			var data = json.place;

			var mapOptions = {
				zoom: 16, 
				center: initLocation, 
				mapTypeId: google.maps.MapTypeId.ROADMAP
			};

			map = new google.maps.Map(document.getElementById('map'), mapOptions);

			data.forEach(function(element, index, array) {
				var d = element.data;

				if (element.category != "support" && element.category != "danger") {
					d = parseInt(element.data);

					if (element.category == "casualty") {
						var min = 0;
						casualtyRange.forEach(function(elem, idx, arr) {
							if (d >= elem)
								min = elem;
						});

						d = min;

					} else if (element.category == "water") {
						var min = 0;
						waterRange.forEach(function(elem, idx, arr) {
							if (d >= elem)
								min = elem;
						});

						d = min;
					}
				}

				var iconW = (element.category + "-" + element.data == "support-hospital") ? 30 : 30, 
					iconH = (element.category + "-" + element.data == "support-hospital") ? 30 : 44;
					

				var marker = new google.maps.Marker({
					position: element.LatLng,
					map: map,
					title: element.title, 
					icon: new google.maps.MarkerImage(
						"images/" + element.category + "-" + d + ".png", // set the icon path
						new google.maps.Size(iconW, iconH), // the icon size
						new google.maps.Point(0, 0), // the start point of the icon
						new google.maps.Point(iconW / 2, iconH), // the end point of the icon
						new google.maps.Size(iconW, iconH) // scale paremeter
					)
				});

				marker.addListener('click', function() {
					if (infoWindow) {
						infoWindow.close();
					}

					var shortData = "";
					if (element.category == "casualty")
						shortData = element.data + " 人";
					else if (element.category == "water")
						shortData = element.data + " 箱";
					else if (element.category == "danger") {
						if (element.data == "NaCN")
							shortData = "氰化鈉危險";
						else if (element.data == "chemical")
							shortData = "化學煙霧危險";
						else
							shortData = "爆裂物危險";
					}
					else {
						if (element.data == "ambulance") 
							shortData = "救護車數輛";
						else if (element.data == "stretcher")
							shortData = "擔架數個";
					}

					infoWindow = new google.maps.InfoWindow({
						content: '<div class="info-window"><div class="info-header">' 
						+ '<p style="left: 5px">' + element.title + '</p>'
						+ '</div>' +'<div class="info-content">' 
						+ shortData + "<br>" + element.description + '</div>' + '<br>'
					});

					infoWindow.open(map, marker);

					// Point the center to the clicked marker
					window.setTimeout(function() {
						map.panTo(marker.getPosition());
					}, 0);
				});

				marker.category= element.category;
				marker.data = element.data;
				marker.description = element.description;
				marker.regionShape = element.regionShape;
				marker.id = idCount;
				
				markers.push(marker);
				idCount++;
			});
		});
	}

	// Function to display markers
	function setMapOnAll(map) {
		for (var i = 0; i < markers.length; i++) {
			markers[i].setMap(map);

			if (markers[i].regionShape != null) {
				markers[i].regionShape.setMap(map);
				console.log(markers[i].title);
			}
		}

		if (infoWindow)
			infoWindow.close();
	}

	// Clear all markers on the map
	function clearMarkers() {
		setMapOnAll(null);
	}

	// Shows any markers currently in the array.
	function showMarkers() {
		setMapOnAll(map);
	}
});

// Used to disable functions
function initTool() {
	$('div.btn-fn').removeClass("btn-clicked");

	if (infoWindow) {
		infoWindow.close();
	}
	
	if(drawingTool.getMap()) {
		drawingTool.setMap(null); // Used to disable the previous function
	}

	google.maps.event.clearListeners(drawingTool, 'overlaycomplete');
}

// Pan map to the current location
function center() {
	if (navigator.geolocation) {
		navigator.geolocation.getCurrentPosition(function (position) {
			mylocation = new google.maps.LatLng(position.coords.latitude, position.coords.longitude);
			map.setCenter(mylocation);
		});
	} else {
		alert('Geolocation is not supported by this browser.');
	}

	if (infoWindow) {
		infoWindow.close();
	}
}

// The map move function
function move() {
	initTool();
	$('div.btn-move').addClass("btn-clicked");
}

function drawMarker() {
	// Initialize
	initTool();
	tmpPosition = null;
	tmpShape = null;

	// Set the function button style to the click style
	$('div.btn-marker').addClass("btn-clicked");

	// Draw the marker
	drawingTool.setOptions({
		drawingMode: google.maps.drawing.OverlayType.MARKER,
		drawingControl: false,
		markerOptions: {
			title: "New Marker",
			clickable: false,
			editable: false,
			zIndex: 1
		}
    });
	
	// Loading the drawn shape in the Map.
	drawingTool.setMap(map);

	// Call the adding form and send data
	var marker;
	google.maps.event.addListener(drawingTool, 'overlaycomplete', function(event) {
		$("#callForm").click();

		marker = event.overlay;
		tmpPosition = marker.position;
		tmpShape = null;
	});

	// Remove the temp marker after the adding form is closed
	$('#myModal').on('hidden.bs.modal', function () {
		tmpPosition = null;

		marker.setMap(null);

		$("input").val(''); 
		$("textarea").val('');
	});
}

function drawCircle() {
	// Initialize
	initTool();
	tmpPosition = null;
	tmpShape = null;

	// Set the function button style to the click style
	$('div.btn-circle').addClass("btn-clicked");

	// Draw the circle
	drawingTool.setOptions({
		drawingMode: google.maps.drawing.OverlayType.CIRCLE,
		drawingControl: false,
		circleOptions: {
			fillColor: '#f01256',
			fillOpacity: 0.2,
			strokeWeight: 0,
			clickable: false,
			editable: false,
			zIndex: 1
		}
    });
	
	// Loading the drawn shape in the Map.
	drawingTool.setMap(map);

	// Call the adding form and send data
	google.maps.event.addListener(drawingTool, 'overlaycomplete', function(event) {
		$("#callForm").click();

		tmpPosition = event.overlay.center;
		tmpShape = event.overlay;
		tmpShape.type = event.type;
	});

	// Check user's behavior to keep/remove the shape
	var ifSave = false;
	
	$('#save').click(function(event) {
		ifSave = true;
	});

	$('#myModal').on('hidden.bs.modal', function () {
		if (!ifSave) {
			tmpShape.setMap(null);
		}
		
		$("input").val(''); 
		$("textarea").val('');
	});
}

function drawPolygon() {
	// Initialize
	initTool();
	tmpPosition = null;
	tmpShape = null;

	// Set the function button style to the click style
	$('div.btn-polygon').addClass("btn-clicked");

	// Draw the polygon
	drawingTool.setOptions({
		drawingMode: google.maps.drawing.OverlayType.POLYGON,
		drawingControl: false,
		polygonOptions: {
			fillColor: '#f01256',
			fillOpacity: 0.2,
			strokeWeight: 0,
			clickable: false,
			editable: false,
			zIndex: 1
		}
    });
	
	// Loading the drawn shape in the Map.
	drawingTool.setMap(map);

	// Call the adding form and send data
	var polygon, path;
	google.maps.event.addListener(drawingTool, 'overlaycomplete', function(event) {
    	$("#callForm").click();

    	tmpShape = event.overlay;
    	tmpShape.type = event.type;
    	path = tmpShape.getPath();
    	tmpPosition = {lat: path.j[0].G, lng: path.j[0].K}; // The first point of the polygon
	});

	// Check user's behavior to keep/remove the shape
	var ifSave = false;
	
	$('#save').click(function(event) {
		ifSave = true;
	});

	$('#myModal').on('hidden.bs.modal', function () {
		if (!ifSave) {
			tmpShape.setMap(null);
		}
		
		$("input").val(''); 
		$("textarea").val('');
	});
}

function drawPolyline() {
	// Initialize
	initTool();
	tmpPosition = null;
	tmpShape = null;

	// Set the function button style to the click style
	$('div.btn-polyline').addClass("btn-clicked");

	// Draw the polyline
	drawingTool.setOptions({
		drawingMode: google.maps.drawing.OverlayType.POLYLINE,
		drawingControl: false,
		polylineOptions: {
			strokeColor: '#f01256',
			strokeWeight: 10,
			clickable: false,
			editable: false,
			zIndex: 1
		}
    });
	
	// Loading the drawn shape in the Map.
	drawingTool.setMap(map);

	// Call the adding form and send data
	var polyline, path;
	google.maps.event.addListener(drawingTool, 'overlaycomplete', function(event) {
		$("#callForm").click();

		tmpShape = event.overlay;
		tmpShape.type = event.type;
		path = tmpShape.getPath();
		tmpPosition = {lat: path.j[0].G, lng: path.j[0].K}; // The first point of the polyline
	});

	// Check user's behavior to keep/remove the shape
	var ifSave = false;
	
	$('#save').click(function(event) {
		ifSave = true;
	});

	$('#myModal').on('hidden.bs.modal', function () {
		if (!ifSave) {
			tmpShape.setMap(null);
		}
		
		$("input").val(''); 
		$("textarea").val('');
	});
}

function saveMarker() {
	var titleName = document.getElementById("title-name").value;
	var dataText = document.getElementById("data-text").value;
	var contentText = document.getElementById("content-text").value;

	$("input").val(''); 
	$("textarea").val('');

	// Determine the data range for choosing the appropriate icon
	var d = dataText;
	if (categoryChosen != "support" && categoryChosen != "danger") {
		d = parseInt(dataText);

		if (categoryChosen == "casualty") {
			var min = 0;
			casualtyRange.forEach(function(elem, idx, arr) {
				if (d >= elem)
					min = elem;
			});

			d = min;

		} else {
			var min = 0;
			waterRange.forEach(function(elem, idx, arr) {
				if (d >= elem)
					min = elem;
			});

			d = min;
		}
	}

	// Since the hospital icon aspect-ratio differs from other icons, need to adjust
	var iconW = (categoryChosen + "-" + dataText == "support-hospital") ? 30 : 30, 
		iconH = (categoryChosen + "-" + dataText == "support-hospital") ? 30 : 44;

	// Put marker on the choosed location
	var marker = new google.maps.Marker({
		position: tmpPosition,
		map: map,
		title: titleName,  
		icon: new google.maps.MarkerImage(
			"images/" + categoryChosen + "-" + d + ".png", // set the icon path
			new google.maps.Size(iconW, iconH), // the icon size
			new google.maps.Point(0, 0), // the start point of the icon
			new google.maps.Point(iconW / 2, iconH), // the anchor point of the icon
			new google.maps.Size(iconW, iconH) // scale paremeter
		)
	});

	// The following marker options are not originally provided by google map api
	marker.category = categoryChosen;
	marker.data = dataText;
	marker.description = contentText;
	marker.regionShape = tmpShape;
	marker.id = idCount;

	// Set the short description for display
	var shortData = "";
	if (categoryChosen == "casualty")
		shortData = dataText + " 人";
	else if (categoryChosen == "water")
		shortData = dataText + " 箱";
	else if (categoryChosen == "danger") {
		if (dataText == "NaCN")
			shortData = "氰化鈉危險";
		else if (dataText == "chemical")
			shortData = "化學煙霧危險";
		else
			shortData = "爆裂物危險";
	}
	else {
		if (dataText == "ambulance") 
			shortData = "救護車數輛";
		else if (dataText == "stretcher")
			shortData = "擔架數個";
	}

	// Bind the info-window to the marker
	google.maps.event.addListener(marker, 'click', function(event){
		if (infoWindow) {
			infoWindow.close();
		}

		infoWindow = new google.maps.InfoWindow({
			content: '<div class="info-window"><div class="info-header">' 
			+ '<p style="left: 5px">' + marker.title + '</p>'
			+ '</div>' +'<div class="info-content">' 
			+ shortData + "<br>" + marker.description + '</div>' + '<br>'
		});

		infoWindow.open(map, marker);

		// Point the center to the clicked marker
		window.setTimeout(function() {
			map.panTo(marker.getPosition());
		}, 0);
	});

	markers.push(marker);
	idCount++;
}

// For choosing the category while adding event
function chooseDanger(){
	categoryChosen = "danger";
	$('.form-check-icon').removeClass('checked');
	$('.form-btn-danger').children('.form-check-icon').addClass('checked');
}

function chooseCasualty(){
	categoryChosen = "casualty";
	$('.form-check-icon').removeClass('checked');
	$('.form-btn-casualty').children('.form-check-icon').addClass('checked');
}

function chooseWater(){
	categoryChosen = "water";
	$('.form-check-icon').removeClass('checked');
	$('.form-btn-water').children('.form-check-icon').addClass('checked');
}

function chooseSupport(){
	categoryChosen = "support"
	$('.form-check-icon').removeClass('checked');
	$('.form-btn-support').children('.form-check-icon').addClass('checked');
}